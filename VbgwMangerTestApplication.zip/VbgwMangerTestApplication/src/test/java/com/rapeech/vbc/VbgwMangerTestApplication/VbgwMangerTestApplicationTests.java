package com.rapeech.vbc.VbgwMangerTestApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VbgwMangerTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
